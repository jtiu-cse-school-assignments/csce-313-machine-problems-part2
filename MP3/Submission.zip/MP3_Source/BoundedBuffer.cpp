#include "BoundedBuffer.H"

using namespace std;

void BoundedBuffer::toBuffer(string request) {
    full.P();
    mutex.P();
	if(count < bufferSize) {
		bbQueue.push(request);
		count++;
	}
    mutex.V();
    empty.V();
}

string BoundedBuffer::fromBuffer() {
	empty.P();
    mutex.P();
    if(count > 0) {
    	string returnString = bbQueue.front();
    	bbQueue.pop();
    	count--;
    	mutex.V();
    	full.V();
    	return returnString;
    }
    else {
    	mutex.V();
    	full.V();
    	return "";
    }
}

void BoundedBuffer::size() {
	printf("BufferSize: %i ", bbQueue.size());
}